
export const environment={
  serveBasePath: undefined
}
